/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.textparser.IntrisecParser;

/**
 *
 * @author Administrator
 */
public class ParsersTypes {
    public static  final int T_PUNCTUATION = 10;    
    public static final int T_STOP_WORDS = 11;    
    public static final int T_PRONOUNS = 12;    
    public static final int T_POS_TAGS = 13;    

}
