/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.textparser.ExtrisecParser;
import com.textparser.Document.ExtrinsecDocument;

/**
 *
 * @author bkt
 */
public interface ExtrinsecListener {
    public void extrinsecParsingComplete(ExtrinsecDocument document);

}
